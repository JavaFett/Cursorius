from .api import TelegramCursorius

__all__ = (
    "TelegramCursorius",
)
