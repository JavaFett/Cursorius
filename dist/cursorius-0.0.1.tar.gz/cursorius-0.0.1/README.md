# Cursorius

`TgCursorius` for delivery message to telegram client
`SMPTCursorius` for delivery message to smtp client
