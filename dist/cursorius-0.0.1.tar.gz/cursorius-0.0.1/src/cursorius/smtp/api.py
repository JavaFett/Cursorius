
class SMTPCursorius:
    def __init__(self, template):
        self._template = template
